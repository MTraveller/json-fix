// src/lib.rs
mod fixer;

pub use fixer::{fix_json, FixReport};
